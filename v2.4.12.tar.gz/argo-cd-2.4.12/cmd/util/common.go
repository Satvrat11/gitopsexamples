package util

var (
	LogFormat string
	LogLevel  string
)
