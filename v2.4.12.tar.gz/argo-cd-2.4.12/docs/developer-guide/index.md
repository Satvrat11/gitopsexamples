# Overview

!!! warning "You probably don't want to be reading this section of the docs."
    This part of the manual is aimed at people wanting to develop third-party applications that interact with Argo CD, e.g.
    
    * A chat bot
    * A Slack integration
    
!!! note
    Please make sure you've completed the [getting started guide](../getting_started.md).
